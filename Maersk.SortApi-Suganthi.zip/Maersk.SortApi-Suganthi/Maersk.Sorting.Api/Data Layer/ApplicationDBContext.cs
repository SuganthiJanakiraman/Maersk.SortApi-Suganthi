﻿using Microsoft.EntityFrameworkCore;

namespace Maersk.Sorting.Api.Data_Layer
{
    public class ApplicationDBContext : DbContext
    {
        public DbSet<SortJobEntity> SortJobs { get; set; } = default!;

        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }
    }
}
