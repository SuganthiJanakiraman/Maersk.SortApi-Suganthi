﻿namespace Maersk.Sorting.Api
{
    public enum SortJobStatus
    {
        Pending,
        Completed
    }
}
